# Mingli site <-> Hermes (added 22 Nov 2026)

Files (copy next to dispatch.py in /data/logistics-agent/):
- `patch_dispatch_rules.py` – adds the 90 h two-week limit and 45 h weekly rest to dispatch.py (backup first).
- `test_dispatch_rules.py` – 7 tests for those rules.
- `mingli_sync.py` – takes dispatcher decisions and new loads from minglilog.com, sends top-3 trucks back.
- `replay_day.py` – past-day test: Mingli's choice vs the dispatcher's real choice.
- `mingli_import.py` – loads the filled company form (Mingli_imones_duomenys.xlsx).

Secrets: MINGLI_KEY is NOT in this repo. Put it only in the Hermes .env:
    MINGLI_URL=https://minglilog.com
    MINGLI_KEY=<from Claude, same as MINGLI_API_KEY in the site's private/config.php>

Check:   python3 mingli_sync.py --test        -> "site reachable, key accepted"
Run:     python3 mingli_sync.py --pull        (cron every 1-2 min while the pilot runs)
