#!/usr/bin/env python3
"""Load a filled 'Mingli_imones_duomenys.xlsx' into Hermes.
   python3 mingli_import.py Mingli_imones_duomenys.xlsx --out data/
Writes data/company_trucks.csv (static truck fields for dispatch.py; GPS fields are filled from LocTracker)
and data/company_clients.json. Real company data: keep it in Hermes only, never on GitHub."""
import argparse, csv, json, os, sys
from openpyxl import load_workbook
TRUCK_COLS = {"Vilkiko nr.": "truck_id", "Priekaba (ref / tent)": "trailer", "Laisva vieta, t": "free_capacity_t",
              "ADR (taip / ne)": "adr_certified", "Vairuotojas": "driver", "Vairuotojo kalbos": "driver_languages",
              "Vairuotojo telefonas": "driver_phone", "Grupė": "group", "Bazė (miestas)": "location", "Pastabos": "notes"}
CLIENT_COLS = {"Klientas": "name", "El. paštas": "email", "Telefonas": "phone", "Svetainė": "web",
               "Kalba (LT / RU / EN / PL)": "lang", "Kontaktinis asmuo": "contact"}
def rows(ws, cols):
    head = [str(c.value or "").strip() for c in ws[1]]
    miss = [h for h in cols if h not in head]
    if miss: sys.exit(f"{ws.title}: missing columns {miss}")
    out = []
    for r in ws.iter_rows(min_row=3, values_only=True):   # row 2 = example
        rec = {cols[h]: ("" if r[i] is None else str(r[i]).strip()) for i, h in enumerate(head) if h in cols}
        if any(rec.values()): out.append(rec)
    return out
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("xlsx"); ap.add_argument("--out", default="data"); a = ap.parse_args()
    wb = load_workbook(a.xlsx, data_only=True)
    trucks, clients, errs = rows(wb["Vilkikai"], TRUCK_COLS), rows(wb["Klientai"], CLIENT_COLS), []
    seen = set()
    for t in trucks:
        tid = " ".join(t["truck_id"].upper().split()); t["truck_id"] = tid
        if not tid: errs.append("empty truck number"); continue
        if tid in seen: errs.append(f"{tid}: duplicate")
        seen.add(tid)
        t["trailer"] = t["trailer"].lower(); t["adr_certified"] = {"taip": "yes", "ne": "no"}.get(t["adr_certified"].lower(), "")
        if t["trailer"] not in ("ref", "tent", ""): errs.append(f"{tid}: trailer must be ref or tent")
        try: float(t["free_capacity_t"] or 0)
        except ValueError: errs.append(f"{tid}: capacity is not a number")
        t["driver_languages"] = ",".join(x.strip().upper() for x in t["driver_languages"].split(",") if x.strip())
    if errs: sys.exit("Fix these rows first:\n- " + "\n- ".join(errs))
    os.makedirs(a.out, exist_ok=True)
    fields = ["truck_id", "location", "trailer", "free_capacity_t", "adr_certified", "driver", "driver_languages", "driver_phone", "group", "notes"]
    with open(os.path.join(a.out, "company_trucks.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(trucks)
    with open(os.path.join(a.out, "company_clients.json"), "w", encoding="utf-8") as f:
        json.dump({c["name"]: c for c in clients if c["name"]}, f, ensure_ascii=False, indent=1)
    print(f"ok: {len(trucks)} trucks, {len(clients)} clients -> {a.out}")
if __name__ == "__main__": main()
