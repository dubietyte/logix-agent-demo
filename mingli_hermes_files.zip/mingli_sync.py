#!/usr/bin/env python3
"""
Mingli site <-> Hermes sync.

  python3 mingli_sync.py --pull            # take dispatcher decisions + new loads from minglilog.com
                                           #   decisions -> monitor.py --decide ...
                                           #   loads     -> dispatch rules (Google road km) -> top-3 back to the site
  python3 mingli_sync.py --push FILE.json  # send a site-format latest.json to the site
  python3 mingli_sync.py --test            # check the connection (no changes)

Needs in the Hermes .env:  MINGLI_URL=https://minglilog.com   MINGLI_KEY=<secret from the site config>
Real client data stays private: it is sent only to our own site over HTTPS, never to GitHub.
"""
import argparse, json, os, subprocess, sys, urllib.error, urllib.request
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def env():
    try:
        import hermes_env; hermes_env.load()
    except Exception:
        pass
    url, key = os.environ.get("MINGLI_URL", "").rstrip("/"), os.environ.get("MINGLI_KEY", "")
    if not url or len(key) < 32:
        sys.exit("MINGLI_URL / MINGLI_KEY missing in .env")
    return url, key


def call(url, key, action, method="GET", data=None):
    req = urllib.request.Request(f"{url}/api.php?a={action}", method=method,
                                 data=json.dumps(data, ensure_ascii=False).encode() if data is not None else None,
                                 headers={"X-Mingli-Key": key, "Content-Type": "application/json", "User-Agent": "mingli-sync/1.0"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.load(r)


def rank_load(load, trucks_csv):
    """Run the same hard rules as dispatch.py for one load against every truck; return top-3 + blocked."""
    import dispatch as d
    order = {"order_id": load["id"], "pickup_city": load["pickup"], "pickup_country": load.get("pickup_country", ""),
             "loaded_distance_km": str(load.get("loadedKm") or ""), "weight_t": str(load["weight"]),
             "pickup_window": f'{load["wStart"][:10]} {load["wStart"][11:16]}-{load["wEnd"][11:16]}',
             "deliver_by": (load.get("deliverBy") or "")[:16].replace("T", " "),
             "temp_min_c": str(load.get("tmin", "")), "temp_max_c": str(load.get("tmax", "")),
             "cargo": load.get("cargoName", ""), "adr": "yes" if load.get("adr") else "no",
             "contact_language": load.get("lang", "LT"), "price_eur": str(load.get("price") or "")}
    trucks = d.read_csv(trucks_csv)
    provider = "google" if os.environ.get("GOOGLE_MAPS_API_KEY") else "osrm"
    D = d.Distances(d.load_cities(), provider)
    D.prefetch([(t.get("available_location") or t["location"]) for t in trucks], [d.place(order["pickup_city"], order["pickup_country"])])
    if not order["loaded_distance_km"]:
        km = D.km(d.place(order["pickup_city"], order["pickup_country"]), load["drop"])
        order["loaded_distance_km"] = str(round(km or 0))
    rows = [d.check(t, order, D) for t in trucks]
    ok = sorted([r for r in rows if not r["fails"] and not r["ask"] and not r.get("skip_reason")],
                key=lambda r: (-(r["eur_km"] or 0), r["empty_km"]))
    blocked = sorted([r for r in rows if r["fails"] and r["empty_km"] is not None and r["empty_km"] <= 300],
                     key=lambda r: r["empty_km"])[:8]
    pick = lambda r: {k: r.get(k) for k in ("truck", "empty_km", "eur_km", "drive_h", "eta", "warns", "fails", "two_week_left_h")}
    return {"id": load["id"], "distance_source": D.used, "checked": len(rows),
            "top": [pick(r) for r in ok[:3]], "blocked": [pick(r) for r in blocked],
            "created": datetime.now().isoformat(timespec="seconds")}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pull", action="store_true")
    ap.add_argument("--push")
    ap.add_argument("--test", action="store_true")
    ap.add_argument("--trucks", default=os.path.join(HERE, "data", "trucks_smartcars.csv"))
    ap.add_argument("--monitor-dir", default=os.path.join(HERE, "data", "day_test"))
    a = ap.parse_args()
    url, key = env()
    if a.test:
        try:
            req = urllib.request.Request(f"{url}/api.php?a=ping", headers={"X-Mingli-Key": key, "User-Agent": "mingli-sync/1.0"})
            urllib.request.urlopen(req, timeout=15)
        except urllib.error.HTTPError as e:
            print("site reachable, key accepted" if e.code == 404 else f"key rejected (HTTP {e.code})")
        except Exception as e:
            print(f"site not reachable: {e}")
        return
    if a.push:
        with open(a.push, encoding="utf-8") as f:
            print(call(url, key, "push", "POST", json.load(f)))
    if a.pull:
        q = call(url, key, "pull")
        for dcs in q.get("decisions", []):
            cmd = [sys.executable, os.path.join(HERE, "monitor.py"), "--dir", a.monitor_dir, "--decide",
                   dcs["plate"], dcs.get("option") or "-", dcs["status"], datetime.now().strftime("%H:%M")]
            res = subprocess.run(cmd, capture_output=True, text=True)
            print("decision", dcs["plate"], dcs["status"], "->", "ok" if res.returncode == 0 else res.stderr[-200:])
        for load in q.get("loads", []):
            try:
                result = rank_load(load, a.trucks)
            except Exception as e:
                result = {"id": load.get("id"), "error": f"{e.__class__.__name__}: {e}"}
            print("load", load.get("id"), "->", call(url, key, "load_result", "POST", result))
        if not q.get("decisions") and not q.get("loads"):
            print("nothing new")


if __name__ == "__main__":
    main()
