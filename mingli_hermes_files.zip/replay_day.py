#!/usr/bin/env python3
"""Test Mingli on one past day: what would Mingli have chosen vs what the dispatcher actually did.

  python3 replay_day.py --trucks data/past_trucks.csv --orders data/past_orders.csv [--provider auto] [--out report.md]

past_orders.csv = the normal dispatch.py orders columns + one extra column `actual_truck`
(the truck the dispatcher really gave the load to; empty = not taken).
past_trucks.csv = the truck snapshot from the START of that day (dispatch.py truck columns).
Prints a short report: top-1 / top-3 agreement, loads where the dispatcher's truck breaks a hard rule,
and the empty km Mingli would have saved. Real data stays in Hermes."""
import argparse, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import dispatch as d

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--trucks", required=True); ap.add_argument("--orders", required=True)
    ap.add_argument("--provider", default="auto", choices=["auto", "google", "osrm", "straight"]); ap.add_argument("--out")
    a = ap.parse_args()
    try:
        import hermes_env; hermes_env.load()
    except Exception:
        pass
    prov = a.provider if a.provider != "auto" else ("google" if os.environ.get("GOOGLE_MAPS_API_KEY") else "osrm")
    trucks, orders = d.read_csv(a.trucks), d.read_csv(a.orders)
    D = d.Distances(d.load_cities(), prov)
    D.prefetch([(t.get("available_location") or t["location"]) for t in trucks], [d.place(o["pickup_city"], o["pickup_country"]) for o in orders])
    lines, n, top1, top3, broke, saved = [], 0, 0, 0, [], 0.0
    lines.append("| Load | Dispatcher | Mingli top-3 | Match | Note |\n|---|---|---|---|---|")
    for o in orders:
        actual = (o.get("actual_truck") or "").strip()
        rows = {t["truck_id"]: d.check(t, o, D) for t in trucks}
        ok = sorted([r for r in rows.values() if not r["fails"] and not r["ask"] and not r.get("skip_reason")],
                    key=lambda r: (-(r["eur_km"] or 0), r["empty_km"]))
        best = [r["truck"] for r in ok[:3]]
        note, match = "", "-"
        if actual:
            n += 1
            if best and actual == best[0]: top1 += 1; match = "top-1"
            elif actual in best: top3 += 1; match = "top-3"
            else: match = "no"
            ar = rows.get(actual)
            if ar is None: note = "truck not in snapshot"
            elif ar["fails"]: broke.append(o["order_id"]); note = "dispatcher's truck breaks: " + "; ".join(ar["fails"])
            elif ok and ar["empty_km"] is not None and ok[0]["empty_km"] is not None and ar["empty_km"] > ok[0]["empty_km"]:
                diff = ar["empty_km"] - ok[0]["empty_km"]; saved += diff; note = f"Mingli: {diff} km less empty"
        else:
            note = "not taken by dispatcher" + (f"; Mingli had {best[0]}" if best else "")
        lines.append(f"| {o['order_id']} | {actual or '-'} | {', '.join(best) or 'none'} | {match} | {note} |")
    pct = lambda x: f"{(100 * x / n):.0f} %" if n else "-"
    head = [f"# Past-day test ({D.used} distances)", "",
            f"- Loads given to a truck by the dispatcher: **{n}**",
            f"- Mingli's 1st choice = dispatcher: **{top1} ({pct(top1)})**; in Mingli's top-3: **{top1 + top3} ({pct(top1 + top3)})**",
            f"- Dispatcher's truck breaks a hard rule: **{len(broke)}** {('(' + ', '.join(broke) + ')') if broke else ''}",
            f"- Empty km Mingli would have saved: **~{saved:.0f} km**", "",
            "Disagreement is not automatically an error: check each 'no' row with the dispatcher (what did he know that the data did not show?).", ""]
    report = "\n".join(head + lines)
    print(report)
    if a.out:
        open(a.out, "w", encoding="utf-8").write(report)

if __name__ == "__main__":
    main()
