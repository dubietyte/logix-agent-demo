"""Tests for the 90 h two-week limit and weekly rest added 22 Nov 2026. Run: python3 test_dispatch_rules.py"""
import dispatch as d
D = d.Distances(d.load_cities(), "straight")
base_truck = dict(truck_id="T1", location="Kaunas, LT", available_location="", available_from="2026-11-18 09:30",
                  free_capacity_t="24", current_load_t="0", current_cargo="", temp_min_c="", temp_max_c="", trailer="ref",
                  adr_certified="no", driver_languages="LT", driving_left_today_h="9", bed_left_h="11",
                  driving_left_this_week_h="40", next_task="", notes="", data_time="2026-11-18T09:30")
order = dict(order_id="O1", pickup_city="Kaunas", pickup_country="LT", loaded_distance_km="300", weight_t="18",
             pickup_window="2026-11-18 11:00-14:00", deliver_by="", temp_min_c="", temp_max_c="", cargo="Popierius",
             adr="no", contact_language="LT", price_eur="700")
def run(**kw):
    t = dict(base_truck); t.update(kw); return d.check(t, order, D)
ok = 0
def expect(name, cond):
    global ok
    print(("PASS " if cond else "FAIL ") + name); ok += cond
r = run(); expect("no new fields -> passes, no warning", not r["fails"])
r = run(driving_last_week_h="50", driving_left_this_week_h="30")   # 50 + 26 driven = 76, 14 h left of 90
expect("90 h: 14 h left, needs 4.3 h -> OK", not r["fails"] and r["two_week_left_h"] == 14)
r = run(driving_last_week_h="56", driving_left_this_week_h="25")   # 56 + 31 = 87 -> 3 h left
expect("90 h: 3 h left, needs 4.3 h -> FAIL two-week", any("two-week" in f for f in r["fails"]))
r = run(driving_last_week_h="", driving_left_this_week_h="30")
expect("90 h unknown -> warning only", not r["fails"] and any("90 h" in w for w in r["warns"]))
r = run(weekly_rest_due="2026-11-18 10:00", available_from="2026-11-18 10:30")
expect("weekly rest before arrival -> FAIL", any("weekly rest" in f for f in r["fails"]))
r = run(weekly_rest_due="2026-11-18 13:00")
expect("weekly rest during delivery -> ETA +45 h, warning", not r["fails"] and r["eta"].startswith("11-20") and any("weekly rest 45 h" in w for w in r["warns"]))
order["deliver_by"] = "2026-11-18 21:00"
r = run(weekly_rest_due="2026-11-18 13:00")
expect("weekly rest during delivery + deadline today -> FAIL deadline", any("deadline" in f for f in r["fails"]))
print(f"{ok}/7 passed")
